#!/usr/bin/env python

from distutils.core import setup

setup(name='Quick RSA',
      version='0.1a',
      py_modules=['src/rsa_decoder'],
      )

